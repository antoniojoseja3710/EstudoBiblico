import React from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';

export default function Verse({ route }) {
  const { chapter, bookName, chapterNumber } = route.params;

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>{bookName} - Capítulo {chapterNumber}</Text>
      {chapter.map((verseText, index) => (
        <View key={index} style={styles.verseContainer}>
          <View style={styles.verseNumberContainer}>
            <Text style={styles.verseNumber}>{index + 1}</Text>
          </View>
          <Text style={styles.verseText}>{verseText}</Text>
        </View>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f3f1ea',
    paddingHorizontal: 20,
    paddingTop: 20,
  },
  title: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#2f557f', // azul profundo para título
    textAlign: 'center',
    marginBottom: 20,
  },
  verseContainer: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 15,
    backgroundColor: '#2f557f',
    padding: 12,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#3e8391',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.15,
    shadowRadius: 3,
    elevation: 2,
  },
  verseNumberContainer: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: '#ffa92d', // destaque para número
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
  },
  verseNumber: {
    fontWeight: 'bold',
    color: '#2f557f', // azul profundo para contraste
    fontSize: 14,
  },
  verseText: {
    flex: 1,
    fontSize: 16,
    color: '#fff', // texto branco sobre verde
    lineHeight: 22,
  },
});