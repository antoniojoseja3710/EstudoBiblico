import { StyleSheet, Dimensions } from "react-native";

const { width } = Dimensions.get("window");

export default StyleSheet.create({
  /* 🧱 CONTAINER GERAL */
  container: {
    flex: 1,
    backgroundColor: "#F7F4EE",
    justifyContent: "center",
  },

  /* 🎴 CARD PRINCIPAL */
  card: {
    backgroundColor: "#2F557F",
    marginHorizontal: 24,
    borderRadius: 16,
    paddingVertical: 26,
    paddingHorizontal: 20,
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 6,
    elevation: 6,
  },

  /* 🏷️ TÍTULOS */
  title: {
    fontSize: 26,
    fontWeight: "bold",
    color: "#F2B544",
    marginBottom: 16,
  },

  context:{
    flexDirection:"row",
    alignItems:'center',
    marginBottom: 20,
  },

  contextText: {
    fontSize: 14,
    color: "#FFFFFF",
    textTransform: "uppercase",
    letterSpacing: 1,
  },

  dot: {
    marginHorizontal: 8,
    color: "#FFC857",
    fontSize: 16,
  },
  
  lessonTitle: {
  fontSize: 18,
  color: "#FFFFFF",
  marginBottom: 4, 
},

  /* ⭐ ESTRELAS */
  starsContainer: {
    flexDirection: "row",
  justifyContent: "center",
  marginVertical: 12,
  },

  /* 🔢 NOTA */
  scoreCircle: {
  width: 110,
  height: 110,
  borderRadius: 55,
  backgroundColor: "#F2B544",
  alignItems: "center",
  justifyContent: "center",
  marginVertical: 20,
  shadowColor: "#000",
  shadowOpacity: 0.3,
  shadowRadius: 6,
  elevation: 6,
},
  score: {
    fontSize: 48,
    fontWeight: "bold",
    color: "#2F557F",
  },

  /* 📝 TEXTO RESULTADO */
  resultText: {
    fontSize: 16,
    color: "#fff",
    textAlign: "center",
    marginTop: 10,
    lineHeight: 22,
  },

  /* 🔘 ÁREA DE BOTÕES */
  buttons: {
    marginTop: 26,
    paddingHorizontal: 24,
  },

  row: {
    flexDirection: "row",
    justifyContent: "space-between",
  },

  /* 🔹 BOTÕES SECUNDÁRIOS */
  secondaryButton: {
    backgroundColor: "#3e8391",
    paddingVertical: 12,
    width: (width - 64) / 2,
    borderRadius: 8,
    alignItems: "center",
  },

  secondaryText: {
    color: "#FFFFFF",
    fontSize: 14,
    fontWeight: "600",
  },

  /* 🟢 BOTÃO PRINCIPAL */
  primaryButton: {
    backgroundColor: "#4F6F52",
    paddingVertical: 14,
    borderRadius: 8,
    alignItems: "center",
    marginTop: 14,
  },

  primaryText: {
    color: "#FFFFFF",
    fontSize: 15,
    fontWeight: "bold",
  },
 
acceptMessage: {
  marginTop: 18,
  fontSize: 15,
  textAlign: "center",
  color: "#fff",
  fontWeight: "600",
  paddingHorizontal: 10,
},
});