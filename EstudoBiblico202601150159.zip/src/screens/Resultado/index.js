import React, { useEffect, useState, useRef } from "react";
import { View, Text, TouchableOpacity, SafeAreaView } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { FontAwesome } from "@expo/vector-icons";
import EBRepository from "../../database/EBRepository";
import styles from "./style";

import * as Sharing from "expo-sharing";
import { captureRef } from "react-native-view-shot";

export default function Resultado({ navigation, route }) {
const { lessonId, score, apelAccepted } = route.params;

  const [acceptedLesson, setAcceptedLesson] = useState(null);
const [acceptMessage, setAcceptMessage] = useState("");

const [categoryName, setCategoryName] = useState("");
const [guideTitle, setGuideTitle] = useState("");
  const [lessonNumber, setLessonNumber] = useState("");
  const [lessonTitle, setLessonTitle] = useState("");

  const cardRef = useRef(null);

  const points = Math.round((score.correct / score.total) * 10);
useEffect(() => {
  loadLesson();
  saveProgress();
}, []);

  useEffect(() => {
  if (apelAccepted === true) {
    const message = getAcceptLessonMessage();
    setAcceptMessage(message);
    setAcceptedLesson(true);
  }
}, [apelAccepted]);

 

const loadLesson = async () => {
  try {
    const repo = new EBRepository();
    await repo.init();

    // 🔹 Lição
    const lesson = await repo.getLessonById(lessonId);

    if (!lesson) return;

    setLessonTitle(lesson.title);
    setLessonNumber(lesson.number);

    // 🔹 Guia
    if (lesson.guide_id) {
      const guide = await repo.getGuideById(lesson.guide_id);

      if (guide) {
        setGuideTitle(guide.title);

        // 🔹 Categoria
        if (guide.category_id) {
          const category = await repo.getCategoryById(guide.category_id);
          if (category) {
            setCategoryName(category.name);
          }
        }
      }
    }

  } catch (error) {
    console.log("Erro ao carregar dados:", error);
  }
};

  const saveProgress = async () => {
    const storedUser = await AsyncStorage.getItem("user");
    if (!storedUser) return;

    const user = JSON.parse(storedUser);
    const repo = new EBRepository();
    await repo.init();

    await repo.saveProgress(
      user.id,
      lessonId,
      score.correct,
      score.total
    );
  };

  const getStarsCount = () => {
    if (points === 10) return 5;
    if (points >= 8) return 4;
    if (points >= 6) return 3;
    if (points >= 4) return 2;
    if (points > 0) return 1;
    return 0;
  };

  const getAcceptLessonMessage = () => {
  const messages = [
    "Que decisão abençoada! Que Deus te ajude a viver esta lição todos os dias.",
    "Amém! Colocar a Palavra em prática transforma vidas.",
    "Que o Espírito Santo te fortaleça a viver o que aprendeu.",
    "Sua decisão alegra o céu! Persevere.",
    "Viver esta lição é um passo de fé. Continue firme!",
    "Que esta lição produza frutos em sua vida.",
    "Deus honra quem decide viver a verdade.",
    "Uma escolha sábia! Que Deus te conduza.",
    "Que esta lição seja visível em suas atitudes.",
    "Aprender é importante, viver é essencial. Parabéns!",
  ];

  return messages[Math.floor(Math.random() * messages.length)];
};

  const renderStars = () => {
    const offsets = [22, 8, 0, 8, 22];
    const stars = getStarsCount();

    return (
      <View style={styles.starsContainer}>
        {[0, 1, 2, 3, 4].map((i) => (
          <FontAwesome
            key={i}
            name="star"
            size={26}
            color={i < stars ? "#FFD100" : "#5E7C7C"}
            style={{
              marginTop: offsets[i],
              marginHorizontal: 6,
            }}
          />
        ))}
      </View>
    );
  };

  const handleShare = async () => {
    const uri = await captureRef(cardRef, {
      format: "png",
      quality: 1,
    });

    await Sharing.shareAsync(uri);
  };
const getResultMessage = () => {

  // ⭐ NOTA MÁXIMA
  if (points === 10) {
    const messages = [
      `Excelente! Você acertou todas as ${score.total} questões.`,
      `Desempenho perfeito! ${score.correct}/${score.total} respostas corretas.`,
      `Resultado extraordinário! Você dominou completamente esta lição.`,
      `Parabéns! Seu aprendizado foi completo nesta lição.`,
    ];
    return messages[Math.floor(Math.random() * messages.length)];
  }

  // ⭐ MUITO BOM
  if (points >= 8) {
    const messages = [
      `Ótimo desempenho! Você acertou ${score.correct} de ${score.total} questões.`,
      `Muito bem! Seu entendimento da lição foi excelente.`,
      `Parabéns! Você teve um ótimo aproveitamento.`,
      `Resultado muito positivo! Continue firme nos estudos.`,
    ];
    return messages[Math.floor(Math.random() * messages.length)];
  }

  // ⭐ BOM / APROVADO
  if (points >= 6) {
    const messages = [
      `Bom trabalho! Você concluiu esta lição com sucesso.`,
      `Parabéns por finalizar a lição. Continue se dedicando.`,
      `Você está no caminho certo. Vamos avançar mais um pouco.`,
      `Cada lição concluída fortalece seu aprendizado.`,
    ];
    return messages[Math.floor(Math.random() * messages.length)];
  }

  // ⭐ PRECISA MELHORAR
  if (points >= 4) {
    const messages = [
      `Você concluiu a lição. Que tal revisar o conteúdo?`,
      `Não desanime! Reestudar ajuda a fixar melhor o aprendizado.`,
      `Continue perseverando. O aprendizado é um processo.`,
      `Com mais atenção, seu desempenho pode melhorar ainda mais.`,
    ];
    return messages[Math.floor(Math.random() * messages.length)];
  }

  // ⭐ NOTA BAIXA
  const messages = [
    `Não desista! Refaça a lição com calma e atenção.`,
    `Cada tentativa é uma oportunidade de aprender.`,
    `Persistir faz parte do crescimento. Tente novamente.`,
    `O aprendizado vem com a prática. Continue firme.`,
  ];

  return messages[Math.floor(Math.random() * messages.length)];
};
  

  return (
    <SafeAreaView style={styles.container}>
      
      {/* 🎴 CARD */}
      <View style={styles.card} ref={cardRef}>
        <Text style={styles.title}>Resultado</Text>
<View style={styles.context}>

<Text style={styles.contextText}>
  {categoryName}
</Text>
<Text style={styles.dot}>•</Text>
<Text style={styles.contextText}>
  {guideTitle}
</Text>


</View>
<Text style={styles.lessonTitle}>
  Lição {lessonNumber} - {lessonTitle} 
</Text>


        {renderStars()}
<View style={styles.scoreCircle}>
  <Text style={styles.score}>{points}</Text>
</View>        

        <Text style={styles.resultText}>
  {getResultMessage()}  *
  {apelAccepted && (
  <Text>
   {acceptMessage}
  </Text>
)}
</Text>

      </View>

      {/* 🔘 BOTÕES */}
      <View style={styles.buttons}>
        <View style={styles.row}>
          <TouchableOpacity
            style={styles.secondaryButton}
            onPress={() => navigation.navigate("Categorias")}
          >
            <Text style={styles.secondaryText}>Categorias</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.secondaryButton}
            onPress={() =>
              navigation.replace("Questionario", {
                lesson: { id: lessonId },
              })
            }
          >
            <Text style={styles.secondaryText}>Repetir</Text>
          </TouchableOpacity>
        </View>

        <TouchableOpacity
          style={styles.primaryButton}
          onPress={handleShare}
        >
          <Text style={styles.primaryText}>Compartilhar</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}