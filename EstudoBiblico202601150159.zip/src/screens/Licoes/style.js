import { StyleSheet, Dimensions } from "react-native";

const screenWidth = Dimensions.get("window").width;
const cardSize = (screenWidth - 60) / 4; // 4 colunas com espaçamento

export default StyleSheet.create({
   container: {
    flex: 1,
    backgroundColor: '#f3f1ea',   
  },

  // 📦 Conteúdo Principal
  mainContent: {
    flex: 1,
    paddingHorizontal: 16,
  },
  licoesText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#2f557f',
    marginBotton: 2,
  },
  guideTitle: {
    color: "#2f557f",
    fontWeight: "bold",
    textAlign: "left",
    marginVertical: 5,
    marginBottom: 20,
    fontSize: 16,
  },

  // 🔲 Grid de Lições
  columnWrapper: {
    justifyContent: "space-between",
    marginBottom: 10,
  },
  lessonCard: {
    width: cardSize,
    height: cardSize,
    borderRadius: 8,
    justifyContent: "center",
    alignItems: "center",
  },
  cardActive: {
    backgroundColor: "#2f557f",
  },
  cardSelected: {
    backgroundColor: "#4f759f",
  },
  lessonNumberText: {
    color: "#fff",
    fontSize: 22,
    fontWeight: "bold",
  },
  starsRow: {
    flexDirection: "row",
    marginTop: 5,
  },

  // 📊 Barra de Seleção
  selectionBar: {
    backgroundColor: "#aabbcc",
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: "center",
    marginVertical: 20,
  },
  selectionBarText: {
    color: "#000",
    fontSize: 20,
    fontWeight: "500",
  },

  // 🔘 Footer
  footerButtons: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 70
  },
  btnVoltar: {
    backgroundColor: "#556677",
    paddingVertical: 10,
    paddingHorizontal: 25,
    borderRadius: 6,
  },
  startButton: {
    backgroundColor: "#3e8391",
    paddingVertical: 10,
    paddingHorizontal: 25,
    borderRadius: 6,
  },
  startButtonText: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 16,
  },

  // ⏳ Loading
  loading: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#E9E6D1",
  },
});