import React from 'react';
import { View, Text, FlatList, StyleSheet } from 'react-native';
import ChapterItem from './ChapterItem';

export default function ChapterList({ route, navigation }) {
  const { book } = route.params;

  return (
    <View style={styles.container}>
      <Text style={styles.title}>{book.nome}</Text>

      <FlatList
        data={book.capitulos}
        keyExtractor={(_, index) => index.toString()}
        numColumns={5}
        renderItem={({ item, index }) => (
          <ChapterItem
            index={index + 1}
            onPress={() =>
              navigation.navigate('Verses', {
                chapter: item,
                bookName: book.nome,
                chapterNumber: index + 1,
              })
            }
          />
        )}
        contentContainerStyle={{ paddingBottom: 20 }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F3F1EA',
    paddingHorizontal: 16,
    paddingTop: 20,
  },
  title: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#2f557f',
    textAlign: 'center',
    marginBottom: 20,
  },
});
