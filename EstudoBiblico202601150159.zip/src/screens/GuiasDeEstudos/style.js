import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f3f1ea',   
  },

  content: {
    padding:20,
    alignItems:"center"
  },

  guideText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#2f557f',
    marginBottom: 10,
  },

  title: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#2f557f',
    marginBottom: 30,
  },
  
  button: {
    width: '100%',
    backgroundColor: '#2f557f',
    paddingVertical: 15,
    borderRadius: 8,
    marginBottom: 15,
    alignItems: 'center',
  },

  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 14,
  },

  backButton: {
    position: 'absolute',
    bottom: 60,
    left: 20,
    backgroundColor: '#556677',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 8,
  },

  backButtonText: {
    color: '#fff',
    fontSize: 16,
  },
});

export default styles;