import { StyleSheet } from 'react-native';

export default StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F7F9FB',
  },
  
  content: {
    padding: 20,
  },

  subtitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#2f557f',
  },

  verse: {
    fontSize: 16,
    fontStyle: 'italic',
    color: '#444',
    marginBottom: 4,
  },

  boxReference:{
    alignItems:'flex-end',
    marginRight:8,
    marginBottom:20,
  },

  reference: {
    fontSize: 14,
    color: '#666',
    marginBottom: 10,
  },

  button: {
    backgroundColor: '#2f557f',
    padding: 14,
    borderRadius: 10,
    alignItems: 'center',
    marginBottom: 16,
  },

  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  
  adminButton: {
    marginTop: 12,
    backgroundColor: '#6C757D',
    paddingVertical: 12,
    borderRadius: 10,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    opacity: 0.9,
  },

  adminButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
    marginLeft: 6,
  },
});