export const lessonsSeed = [
  {
    category: "Fundamentos do Evangelho",
    guide: "Fundamentos da Fé Cristã",
    lessons: [
      {
        number: 1,
        title: "O amor de Deus",
        introduction: "Deus nos ama desde a criação.",
        conclusion: "O amor de Deus é eterno.",
        questions: [
          {
            question: "Quem nos amou primeiro?",
            verse: "1 João 4:19",
            option_a: "Nós amamos a Deus",
            option_b: "Deus nos amou primeiro",
            option_c: "Os profetas",
            option_d: "A igreja",
            correct_option: "B",
          },
          {
            question: "Como Deus demonstrou Seu amor?",
            verse: "Romanos 5:8",
            option_a: "Criando o mundo",
            option_b: "Enviando anjos",
            option_c: "Enviando Seu Filho",
            option_d: "Dando riquezas",
            correct_option: "C",
          },
          {
            question: "Deus é amor segundo qual texto?",
            verse: "1 João 4:8",
            option_a: "Salmos",
            option_b: "Romanos",
            option_c: "Gênesis",
            option_d: "1 João",
            correct_option: "D",
          },
        ],
      },

      {
        number: 2,
        title: "O pecado e suas consequências",
        introduction: "O pecado separou o homem de Deus.",
        conclusion: "Cristo restaura nossa comunhão.",
        questions: [
          {
            question: "O que o pecado causa?",
            verse: "Isaías 59:2",
            option_a: "Aproximação",
            option_b: "Separação",
            option_c: "Alegria",
            option_d: "Liberdade",
            correct_option: "B",
          },
        ],
      },
    ],
  },

  {
    category: "Profecia",
    guide: "Profecias Bíblicas",
    lessons: [
      {
        number: 1,
        title: "Daniel e as profecias",
        introduction: "Deus revela o futuro aos seus servos.",
        conclusion: "As profecias fortalecem nossa fé.",
        questions: [
          {
            question: "Quem revelou os sonhos a Daniel?",
            verse: "Daniel 2:28",
            option_a: "O rei",
            option_b: "Os magos",
            option_c: "Deus",
            option_d: "Os sábios",
            correct_option: "C",
          },
        ],
      },
    ],
  },

  {
    category: "Família",
    guide: "Lição do Primário",
    lessons: [
      {
        number: 1,
        title: "O Sábado",
        introduction: "Deus instituiu o Sábado.",
        conclusion: "O Sábado é um presente de Deus.",
        questions: [
          {
            question: "Onde foi o primeiro sábado?",
            verse: "Gênesis 2:3",
            option_a: "No Céu",
            option_b: "Nos Planetas",
            option_c: "No Éden",
            option_d: "Na arca",
            correct_option: "C",
          },
          {
            question: "O casal adão e eva descansaram porque?",
            verse: "Gênesis 2:3",
            option_a: "Porque estavam cansado",
            option_b: "Por que Deus mandou",
            option_c: "Porque não ter outra opção",
            option_d: "Porque estava dominado pelo pecado",
            correct_option: "B",
          },
          {
            question: "Qual dia Deus abençoou?",
            verse: "Gênesis 2:3",
            option_a: "O primeiro dia",
            option_b: "O quarto dia",
            option_c: "Nenhum dia",
            option_d: "O Sétimo Dia",
            correct_option: "D",
          },
          {
            question: "O que podemos fazer no Sábado?",
            verse: "Gênesis 2:3",
            option_a: "Trabalhar",
            option_b: "Nenhum trabalho",
            option_c: "Todas as coisas",
            option_d: "O que quisermos",
            correct_option: "B",
          },
          {
            question: "O Sábado é:",
            verse: "Gênesis 2:3",
            option_a: "O dia mais especial",
            option_b: "O dia mais triste",
            option_c: "O dia mais longo",
            option_d: "O que Deus não guardou",
            correct_option: "A",
          },
          {
            question: "Qual livro da bíblia cita primeiro o Sábado?",
            verse: "Gênesis 2:3",
            option_a: "Gênesis",
            option_b: "Êxodo",
            option_c: "levítico",
            option_d: "Numeros",
            correct_option: "A",
          },
          {
            question: "Qual é o primeiro dia da semana?",
            verse: "Gênesis 2:3",
            option_a: "O Sábado",
            option_b: "O Domingo",
            option_c: "A Segunda",
            option_d: "A Sexta",
            correct_option: "B",
          },
        ],
      },
    ],
  },

  {
    category: "Missão",
    guide: "Missão Cristã",
    lessons: [
      {
        number: 1,
        title: "Chamados para servir",
        introduction: "Todo cristão é chamado para a missão.",
        conclusion: "A missão continua até hoje.",
        questions: [
          {
            question: "Qual é a missão da igreja?",
            verse: "Mateus 28:19",
            option_a: "Reunir pessoas",
            option_b: "Fazer discípulos",
            option_c: "Construir templos",
            option_d: "Cuidar apenas dos membros",
            correct_option: "B",
          },
        ],
      },
    ],
  },
];